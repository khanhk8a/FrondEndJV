

alert('tải js thành công từ file bên ngoài');